ARCHIFY NATIVE STORY / COMPARISON PROTOTYPE

Open checkout-flow.story.html in a current desktop browser. Use the native
Viewer’s Motion control until it says Story, then press Play or drag the
timeline. The light/dark appearance follows the Viewer. Use Sound off for
a silent comparison. The player opens paused and the entire run is 22.9 s:
6 s overview, 5.95 s Before, 5.95 s After, 5 s conclusion.

Before: checkout waits on inline SMTP delivery. After: checkout accepts
the order once the queue accepts the event; a worker sends the email later.
It is a synthetic architecture example, not a measured production claim.

This is the original Viewer attachment workflow from Archify #1036, not
the component Choreography SVG, standalone Stage, or CLI video path. The
Before and After chapters spotlight two paths on one native architecture
diagram. They do not morph components across separate diagrams.

Sources: checkout-flow.architecture.json and checkout-flow.brief.json
are the two authoring inputs. checkout-flow.brief.source.json is the
actual draft source map. checkout-flow.native.html is the unenhanced
diagram. checkout-flow.story.html is the portable attached Viewer.

Release: Archify v3.3.0; see archify/references/story-authoring.md.
With the release checkout as cwd and this directory as OUT:
  node archify/bin/archify.mjs render architecture "$OUT/checkout-flow.architecture.json" "$OUT/checkout-flow.native.html"
  node archify/bin/archify.mjs story scan "$OUT/checkout-flow.native.html" --json
  node archify/bin/archify.mjs story attach "$OUT/checkout-flow.native.html" "$OUT/checkout-flow.brief.json" "$OUT/checkout-flow.story.html" --json

Static CLI and payload checks passed. Local Chromium startup was blocked
before page load, so playback and the optional video were not verified.
